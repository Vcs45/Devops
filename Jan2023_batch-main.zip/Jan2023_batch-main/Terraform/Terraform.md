# Download terrform from below link

https://developer.hashicorp.com/terraform/downloads
